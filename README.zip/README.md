# Library Management System

This project is a **Node.js + Express + MongoDB** based Library Management System with JWT authentication.

## Features
- User Registration & Login
- JWT Authentication
- Admin CRUD books
- Borrow & Return system

## Run
```
npm install
npm run dev
```
