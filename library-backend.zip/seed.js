/*
  Seed script to insert sample users and books.
  Run: npm run seed
*/
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./src/models/User');
const Book = require('./src/models/Book');

async function main() {
  const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/librarydb';
  await mongoose.connect(uri);

  await User.deleteMany({});
  await Book.deleteMany({});

  const adminPass = await bcrypt.hash('adminpass', 10);
  const userPass = await bcrypt.hash('userpass', 10);

  await User.create([
    { name: 'Admin', username: 'admin', password: adminPass, email: 'admin@example.com', mobile: 1111111111, admin: true },
    { name: 'User1', username: 'user1', password: userPass, email: 'user1@example.com', mobile: 2222222222, admin: false },
    { name: 'User2', username: 'user2', password: userPass, email: 'user2@example.com', mobile: 3333333333, admin: false }
  ]);

  await Book.create([
    { name: 'Clean Code', author: 'Robert C. Martin', genre: 'Programming', type: 'Paperback', available: true },
    { name: 'Eloquent JavaScript', author: 'Marijn Haverbeke', genre: 'Programming', type: 'Paperback', available: true },
    { name: 'You Don\'t Know JS', author: 'Kyle Simpson', genre: 'Programming', type: 'Paperback', available: true },
    { name: 'The Pragmatic Programmer', author: 'Andrew Hunt', genre: 'Programming', type: 'Hardcover', available: true },
    { name: 'Design Patterns', author: 'Gamma et al.', genre: 'Programming', type: 'Hardcover', available: true }
  ]);

  console.log('Seed complete');
  process.exit(0);
}

main().catch(err => { console.error(err); process.exit(1); });
