require('dotenv').config();
const express = require('express');
const connectDB = require('./src/config/db');
const app = express();
const port = process.env.PORT || 4000;

app.use(express.json());

// connect db
connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/librarydb');

// routes
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/users', require('./src/routes/users'));
app.use('/api/books', require('./src/routes/books'));
app.use('/api', require('./src/routes/borrowReturn'));

app.get('/', (req, res) => res.send('Library Management API running'));

app.listen(port, () => {
  console.log('Server running on port', port);
});
