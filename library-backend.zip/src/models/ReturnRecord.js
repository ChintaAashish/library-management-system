const mongoose = require('mongoose');

const ReturnSchema = new mongoose.Schema({
  username: String,
  bookId: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
  dueDate: { type: Date },
  fine: Number
}, { timestamps: true });

module.exports = mongoose.model('ReturnRecord', ReturnSchema);
