const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const Borrow = require('../models/BorrowRecord');
const ReturnRec = require('../models/ReturnRecord');
const { authenticateToken } = require('../middleware/auth');

// borrow book
router.post('/borrow', authenticateToken, async (req, res) => {
  try {
    const { bookId } = req.body;
    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    if (!book.available) return res.status(400).json({ message: 'Book not available' });

    const borrow = new Borrow({ username: req.user.username, bookId });
    await borrow.save();
    book.available = false;
    await book.save();
    res.json({ message: 'Book borrowed', borrow });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// return book
router.post('/return', authenticateToken, async (req, res) => {
  try {
    const { bookId } = req.body;
    const borrow = await Borrow.findOne({ bookId, username: req.user.username });
    if (!borrow) return res.status(404).json({ message: 'No borrow record found' });

    const due = borrow.dueDate;
    const now = new Date();
    let fine = 0;
    if (now > due) {
      const daysLate = Math.ceil((now - due)/(24*60*60*1000));
      fine = daysLate * 10; // simple fine calculation
    }

    const ret = new ReturnRec({ username: req.user.username, bookId, dueDate: borrow.dueDate, fine });
    await ret.save();
    await Borrow.deleteOne({ _id: borrow._id });

    const book = await Book.findById(bookId);
    if (book) { book.available = true; await book.save(); }

    res.json({ message: 'Book returned', fine });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
