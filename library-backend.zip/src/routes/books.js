const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

router.get('/', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

router.post('/', authenticateToken, requireAdmin, async (req, res) => {
  const { name, author, genre, type, available } = req.body;
  const book = new Book({ name, author, genre, type, available });
  await book.save();
  res.json(book);
});

router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!book) return res.status(404).json({ message: 'Book not found' });
  res.json(book);
});

module.exports = router;
