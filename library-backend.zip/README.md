# Library Management System (Express + MongoDB)

## Quick start

1. Copy `.env.example` to `.env` and fill `MONGO_URI` and `ACCESS_TOKEN_SECRET`.
2. Install dependencies:
   ```
   npm install
   ```
3. Seed the database with example data (optional):
   ```
   npm run seed
   ```
4. Start server:
   ```
   npm run dev
   ```
5. Use Postman to test endpoints described below.

## Endpoints (summary)

- `POST /api/auth/register` : Register user (body: name, username, password, email, mobile, admin)
- `POST /api/auth/login` : Login (body: username, password) -> returns JWT token
- `GET /api/users` : Get all users (protected, admin only)
- `GET /api/books` : Get all books (public)
- `POST /api/books` : Create new book (protected, admin only)
- `PUT /api/books/:id` : Update book (protected, admin only)
- `POST /api/borrow` : Borrow a book (protected)
- `POST /api/return` : Return a book (protected)

See code for request/response examples.
